score = 1
number = 5
factorial = True
while factorial:
    if number <= 0:
       break
    else:
       score = score *number
       number -= 1
           
print(score)
