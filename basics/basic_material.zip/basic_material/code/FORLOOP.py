fruits = ['apple', 'banana', 'orange', 'kiwi', 'mango']
for i in range(len(fruits)):
    print(fruits[i])
