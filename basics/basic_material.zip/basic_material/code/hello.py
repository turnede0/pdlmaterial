name = "hello" # strings are a type of data type and require "" in this case "hello" 
print(name) # print statement outputs the data stored inside name which is a variable