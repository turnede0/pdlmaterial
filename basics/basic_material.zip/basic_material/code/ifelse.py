hungry = True
money = 0

if hungry and money > 5:
    print("let's buy pizza")

elif hungry and money!=0:
    print("let's buy chocolate")

else:
    print("let's go home")

a = hungry and money

